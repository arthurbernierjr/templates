$(document).ready(function(){
	$('#navbar').click(function(){
		$('.menu-area').slideToggle();
		return false;
	});
	
});